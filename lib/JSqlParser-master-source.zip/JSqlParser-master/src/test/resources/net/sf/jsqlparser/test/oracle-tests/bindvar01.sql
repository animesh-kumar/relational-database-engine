insert into p
(
a1,
b2,
c3,
d4,
e5,
f6,
g7,
h8
)
values
( :b1, :b2, :b3, :b4, :5, :6, :7, :8)


select
 +1,
 t2.division_name as aaaa,
 a.*,
 sum(t3.amount)
from dual


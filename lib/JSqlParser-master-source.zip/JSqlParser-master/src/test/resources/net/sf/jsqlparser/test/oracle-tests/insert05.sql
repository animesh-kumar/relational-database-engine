-- insert all
insert all
into t (pid, fname, lname)
values (1, 'dan', 'morgan')
into t (pid, fname, lname)
values (2, 'jeremiah', 'wilton')
into t (pid, fname, lname)
values (3, 'helen', 'lofstrom')
select * from dual

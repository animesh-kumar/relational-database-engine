select
timestamp '2009-10-29 01:30:00'
from dual


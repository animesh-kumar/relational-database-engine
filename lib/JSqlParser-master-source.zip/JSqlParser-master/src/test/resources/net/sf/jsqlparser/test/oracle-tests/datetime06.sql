select * from dual where sysdate > date '2013-04-10'

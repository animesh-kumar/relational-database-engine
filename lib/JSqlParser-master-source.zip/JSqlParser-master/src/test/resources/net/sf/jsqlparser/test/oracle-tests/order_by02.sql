select * from dual order by 1 asc
